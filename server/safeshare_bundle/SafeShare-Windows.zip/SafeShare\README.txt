SafeShare - private file transfer over your Wi-Fi
==================================================

Send photos, videos, apps, documents and code between PCs and phones
(iPhone and Android) on the same Wi-Fi. Files are copied byte-for-byte:
no compression, no quality loss (HDR, 4K and HEIC stay original).

START
  1. Unzip this folder somewhere permanent (e.g. Documents\SafeShare).
  2. Double-click SafeShare.exe.
     - The first time, SafeShare adds a Desktop icon, a Start menu entry,
       right-click "Send to > SafeShare", and pins its folder to Quick Access.
     - If Windows SmartScreen says "Windows protected your PC", click
       "More info" > "Run anyway" (the app is not code-signed).
     - If Windows Firewall asks, allow it on PRIVATE networks only.

CONNECT A PHONE OR ANOTHER PC
  Join the same Wi-Fi, then scan the QR code shown in SafeShare with the
  phone camera - or open the shown address in any browser and type the PIN.
  Nothing needs to be installed on the phone. On the phone you can use
  "Add to Home Screen" to get a SafeShare icon there too.

INBOX
  Every new file (from phones, PCs, links, right-click Send to) arrives in
  the Inbox first. Select files there and tap Move to put them in your folders.

DOWNLOAD FROM A LINK
  Tap "From link", paste a direct download link (movie, photo, app...) and the
  PC downloads it straight into the Inbox. Tip: set your browser's download
  location to Downloads\SafeShare\Inbox to save browser downloads there too.

ORGANIZE
  Create folders, move, rename, search, preview photos/videos/code,
  download folders as ZIP, unpack ZIPs. Only the PC can delete files.

SHARE WITH OTHERS
  Select a file or folder > Share. Anyone on your Wi-Fi can download it with
  the link or QR code (no PIN, download-only, valid 24 hours).

USE FILES IN OTHER APPS
  All files live in  Downloads\SafeShare  - pinned in Quick Access, so every
  app's Open / Upload dialog shows "SafeShare" in the left sidebar.

INTERNET
  Not needed. Everything works offline over Wi-Fi or a phone hotspot.
  Only "From link" downloads use the internet.

HELP
  Tap the ? button at the top of SafeShare for the full guide.

SECURITY
  - Works only on your local network; nothing goes to the internet.
  - A new random PIN each start; wrong PINs are locked out.
  - Closing the SafeShare window stops sharing.
  - Use it on your home Wi-Fi, not on public Wi-Fi (traffic is not encrypted).

REMOVE
  Delete the shortcuts (or run:  SafeShare.exe --uninstall), then delete
  this folder. Your received files in Downloads\SafeShare are kept.
